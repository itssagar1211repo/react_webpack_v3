var path = require('path')
webpack = require('webpack')
const ExtractTextPlugin = require('extract-text-webpack-plugin');
module.exports ={
 entry:'./src/client.js',
 output:{
   path:"./",
   filename:'index.js'
 },
  devServer:{
        inline:true,
        contentBase:'./public',
        port:3000
    },
    module:{
      loaders:[{test:/\.js$/,
      exclude:/node_modules/,
      loader:'babel-loader'
      },
     { 
       test:/\.css$/, 
      loader:ExtractTextPlugin.extract(['css'])}
    ]
    },
    plugins:[new ExtractTextPlugin('app.css')],
    resolve: { extensions: ['', '.js', '.jsx','.css'] }
}