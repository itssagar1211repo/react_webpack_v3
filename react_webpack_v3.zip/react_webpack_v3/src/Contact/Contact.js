import React, { Component } from 'react'

class Contact extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return <div>See the Contact details here!!</div>
  }
}

export default Contact
