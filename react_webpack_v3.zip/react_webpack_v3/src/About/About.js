import React, { Component } from 'react'

class About extends Component {
  constructor (props) {
    super(props)
    this.state = props.location.state
    console.log(this.state)
  }

  render () {
    return <div>You are now in About section !!</div>
  }
}

export default About
