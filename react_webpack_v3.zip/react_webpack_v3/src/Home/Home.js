import React, { Component } from "react"
class Home extends Component {
  constructor(props) {
    super(props)
 }


  render() {

    return (
      <div>
        Welcome from Home !!!
      </div>
    )
  }

  componentWillUnmount() {
    console.log('consoling unmount')
  }
}

export default Home
