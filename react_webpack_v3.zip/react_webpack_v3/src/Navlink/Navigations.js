import React, { Component } from 'react'
import { Router, Route, Link, hashHistory } from 'react-router'  
import Home from '../Home/Home'
import About from '../About/About'
import Contact from '../Contact/Contact'
import App from '../App'
class Navigations extends Component {
  constructor (props) {
    super(props)
  }

  render () {
    return (
      <div>
        hello
        <Router history={hashHistory}>
           <div>
             <nav>
              <ul>
                <li>
                  <Link to="/">Home</Link>
                </li>
                <li>
                  <Link to="/about/">About</Link>
                </li>
                <li>
                  <Link to="/contact/">contact</Link>
                </li>
              </ul>
            </nav>
               
        <Route path="/" component={App}>
          <IndexRoute component={Home} />
          <Route path="about" component={About} />
          <Route path="contact" component={Contact} />
        </Route>
          </div>
       </Router>
       </div>
    )
  }
}

export default Navigations
