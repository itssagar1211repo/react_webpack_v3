import React from 'react'
import { render } from 'react-dom'
import Home from './Home/Home'
import About from './About/About'
import Contact from './Contact/Contact'
import './App.css'
import { Router, Route, IndexRoute, Link, hashHistory } from 'react-router'
const App = React.createClass({
  render() {
    return (
      <div>
        <h1 className="bgColor">App</h1>
        {/* change the <a>s to <Link>s */}
        <ul>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>

        {/*
          next we replace `<Child>` with `this.props.children`
          the router will figure out the children for us
        */}
        {this.props.children}
      </div>
    )
  }
})

// Finally, we render a <Router> with some <Route>s.
// It does all the fancy routing stuff for us.
render((
  <Router history={hashHistory}>
    <Route path="/" component={App}>
      <IndexRoute component={Home} />
      <Route path="about" component={About} />
      <Route path="contact" component={Contact} />
    </Route>
  </Router>
), document.body)